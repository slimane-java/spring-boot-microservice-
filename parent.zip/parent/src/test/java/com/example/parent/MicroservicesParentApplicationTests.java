package com.example.parent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
