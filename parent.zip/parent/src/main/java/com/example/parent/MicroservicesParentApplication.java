package com.example.parent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesParentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesParentApplication.class, args);
	}

}
